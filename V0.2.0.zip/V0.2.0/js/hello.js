//Prérequis
'use strict';

var versLeJeu = document.getElementById('versLeJeu'),
	valeurEntree = document.getElementById('valeurEntree');


//Fonction Start : préparation de la partie, selon le choix du joueur

function start(gamestart) {
	if (gamestart == 1) {
		alert('Nouvelle partie !');
		valeurEntree.value = 1;
		versLeJeu.submit();
	} else if (gamestart == 2) {
		alert('Alors, où en étions-nous déjà ?');
		window.location.href = 'game.php';
	} else {
		alert('Work In Progress');
	}
}

//Lorsque le joueur clique sur "Commencer une nouvelle partie", on charge une nouvelle partie.
var ngame = document.getElementById('newgame');
	ngame.addEventListener('click', function () { start(1); }, false);

//Lorsque le joueur clique sur "Continuer ma partie", on charge la partie du joueur.
var cgame = document.getElementById('continuegame');
	cgame.addEventListener('click', function () { start(2); }, false);

//Lorsque le joueur clique sur "Découvrir l'agence", on charge la page de l'agence.
var agency = document.getElementById('agency');
	agency.addEventListener('click', function () { start(3); }, false);