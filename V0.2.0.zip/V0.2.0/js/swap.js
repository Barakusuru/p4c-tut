'use strict';

function swap(img, txt, ext) {
    if (window.matchMedia('(max-width: 480px)').matches && window.matchMedia('(orientation: landscape)').matches) {
    	img.style.display = 'none';
		txt.style.display = 'block';
		ext.style.display = 'block';
    }
}


/* Au clic ou toucher de l'utilisateur : l'image laisse place au texte */
var landImg = document.getElementsByClassName('img_');
var landTxt = document.getElementsByClassName('txt_');
var landExt = document.getElementsByClassName('ext_');

landImg[0].addEventListener('click', function() {
	swap(landImg[0], landTxt[0], landExt[0]);
}, false);

