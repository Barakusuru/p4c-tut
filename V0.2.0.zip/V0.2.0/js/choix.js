'use strict';

var choix_user_1 = document.getElementsByClassName('chx_1'),
	choix_user_2 = document.getElementsByClassName('chx_2'),
	choix_form = document.getElementById('choix');


function suite(choix) {
	console.log(choix); /* Débogage */
	choix_form.value = choix;
	choix_form.submit();
}

choix_user_1.addEventListener('click', function() {
	suite(choix_user_1.innerHTML);
}, false);

choix_user_2.addEventListener('click', function() {
	suite(choix_user_2.innerHTML);
}, false);
