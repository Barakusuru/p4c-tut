'use strict';
$(document).ready(function() { // On attend la fin du chargement de la page
	$("button[name=connection_error]").on('click', 
	function() {
		window.location.href = 'userdisconnect.php';
	});
});