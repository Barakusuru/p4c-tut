<?php
	/* Connection à la base de données */
	$user = "root"; 
	$passwd = ""; 
	$host = "localhost";
	$nomBase = "par4chemins_v0.2.0";

	$connexion = mysqli_connect($host,$user,$passwd) or die("ERREUR BASE");
	mysqli_select_db($connexion, $nomBase);	
?>