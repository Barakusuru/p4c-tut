<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="UTF-8">
	<title>Par 4 Chemins : requêtes tests</title>
</head>
<body>
<?php
	include('../data/connection.php');
	$requete_choix = "SELECT * FROM choix WHERE choix.contenu = 'Ouvrir la porte'";
		$result_choix = mysqli_query($connexion,$requete_choix) or die ("\"" . $requete_choix . "\"" . " n'a pas fonctionné");
		var_dump($result_choix);
		global $numchoix;
		while ($tab_choix = mysqli_fetch_assoc($result_choix)) {
			$numchoix = $tab_choix["numero"];
			echo $numchoix;
		}
?>
	
</body>
</html>