<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="UTF-8">
    <title>Par 4 Chemins : TABLEAU</title>
</head>
<body>
	<?php 
		include('connection.php');

		$requete_h = "SELECT * FROM histoire ORDER BY id";
		$result_h = mysqli_query($connexion,$requete_h);
		$requete_c = "SELECT * FROM choix ORDER BY id";
		$result_c = mysqli_query($connexion,$requete_c);
	?>
	<h2>TABLEAU HISTOIRE</h2>
	<table> <!-- Table de tous les résultats -->
		<?php
			while ($tab_h = mysqli_fetch_assoc($result_h)) {
				echo "<tr><td>{$tab_h["id"]}</td>" . "<td>{$tab_h["texte"]}</td>" ."<td>{$tab_h["acte"]}</td>" . "<td>{$tab_h["chapitre"]}</td>" . "<td>{$tab_h["type"]}</td>" . "<td>{$tab_h["options"]}</td>" . "<td>{$tab_h["clef"]}</td></tr>";
			}
		?>
	</table>
	<br /><br />
	<h2>TABLEAU CHOIX</h2>
	<table> <!-- Table de tous les résultats -->
		<?php
			while ($tab_c = mysqli_fetch_assoc($result_c)) {
				echo "<tr><td>{$tab_c["id"]}</td>" . "<td>{$tab_c["contenu"]}</td>" ."<td>{$tab_c["numero"]}</td>";
			}
		?>
	</table>
</body>
</html>