<?php 
	// Cette page gère le chargement de la partie de l'histoire qui correspond au joueur.
	
?>