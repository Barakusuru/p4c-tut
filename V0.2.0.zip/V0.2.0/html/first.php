<?php 
	/* Ouverture d'une session, qui permet au navigateur de sauvegarder des données dans la variable superglobale "$_SESSION" */
	session_start();
?>


<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <link rel="stylesheet" href="book.css" />
    <title>Par 4 Chemins : écran d'accueil</title>
</head>
<body>
	<button type="button" id="newgame"> -> Commencer une nouvelle partie</button>
	<button type="button" id="continuegame"> -> Continuer votre partie</button>
	<button type="button" id="agency"> -> Découvrir l'agence</button>

	<form id="versLeJeu" method="post" action="game.php">
		<input type="hidden" name="valeurEntree" id="valeurEntree" value="" />
	</form>

	<script src="../js/hello.js"></script>
</body>
</html>