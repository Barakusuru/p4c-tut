<!-- NOTES DE PROGRAMMATION 

. Système de données à enregistrer temporairement (dans $_SESSION) et pour toujours (dans la BDD).

. Lorsque l'on ajoute ou modifie une donnée, elle doit passer dans un index de $_SESSION, sans toucher à la BDD.

. Mais lorsque l'on enregistre, les index de $_SESSION doivent être "vidés", une fois les données transvasées dans la BDD.

-->


<?php 
	/* Ouverture d'une session, qui permet au navigateur de sauvegarder des données dans la variable superglobale "$_SESSION" */
	session_start();

	/* Connection à la base de données "par4chemins_tests" */
	include('../data/connection.php');

	/* Variables à passer en entrée à leurs emplacements respectifs ci-dessous */
	$id = "id";
	$titre = "titre";
	$texte = "texte";
	$acte = "acte";
	$chapitre = "chapitre";
	$type = "type";
	$clef = "clef";
	$options = "options";

	/* Vérification des changements effectués lors du rechargement de la page */

		/* Si la session a une valeur déjà enregistrée et que la variable $_POST["num"] n'est pas définie, c'est qu'on a ajouté une option, on cherche donc à obtenir la même page.
		On donne donc à $_POST["num"] la valeur $_SESSION["num"]. */
		if (!isset($_POST["num"]) && isset($_SESSION["num"])) { $_POST["num"] = $_SESSION["num"]; }

		/* Si un id a été recherché : */
		if (isset($_POST["num"])) {	
			/* On cherche dans la table "histoire" l'id qui est associé au numéro recherché */
			$reqPage = "SELECT * FROM histoire WHERE histoire.id = '{$_POST["num"]}'";
			$resPage = mysqli_query($connexion,$reqPage) or die ("\"" . $reqPage . "\"" . " n'a pas fonctionné");
			while ($tabPage = mysqli_fetch_assoc($resPage)) {
				/* Le tableau associatif "page" accueille les informations de la page courante */
				$page = [ 
					"id" => $tabPage["id"],
					"titre" => $tabPage["titre"],
					"texte" => $tabPage["texte"],
					"acte" => $tabPage["acte"],
					"chapitre" => $tabPage["chapitre"],
					"type" => $tabPage["type"],
					"clef" => $tabPage["clef"],
					"options" => $tabPage["options"]
				];

				/* En cas de changements sur la page, on aura besoin d'un espace de stockage qui se souvient des données de la page choisie même en cas de rechargement : ici, la variable superglobale $_SESSION. */
				if ($_SESSION["num"] != $tabPage["id"]) {
					$_SESSION["num"] = $tabPage["id"];

					$_SESSION["titre"] = $tabPage["titre"];
					$_SESSION["options"] = $tabPage["options"];
				}	
			}

			/* Si une option a été ajoutée */
			if (isset($_POST["ajouter_option"])) {
				$_SESSION[$options] = ajouterOption($_SESSION, $options, $_POST["ajouter_option"]);
			}

			/* Si on enregistre les données */
			if (isset($_POST["enregistrer"])) {
				enregistrer($_SESSION, $page);
			}
		}
		
	/* Fonctions */

		/* Ajouter une option */
		function ajouterOption($pageSelectionnee, $optionsDePage, $nouveauChoix) {
			/* On ajoute à $page[$options] la chaîne de caractères $nouveauChoix, précédée de " / " */
			$pageSelectionnee[$optionsDePage] = $pageSelectionnee[$optionsDePage] . " / " . $nouveauChoix;
			return $pageSelectionnee[$optionsDePage];
		}

		/* Enregistrer les modifications */
		function enregistrer($tableauNouvellesDonnees, $tableauAnciennesDonnees) {
			/* Appel de la variable globale "$connexion", qui permet de se connecter à la BDD */
			global $connexion;

			/* On crée un tableau associatif "$tab_enr", qui contient les index du $tableauNouvellesDonnees différents de ceux du $tableauAnciennesDonnees*/
			$tab_enr = array_diff_assoc($tableauNouvellesDonnees, $tableauAnciennesDonnees);

			/* Cette boucle foreach gère ensuite les cas où les valeurs pour les deux index (ici, celui de $_SESSION et celui de $page) sont différents */
			foreach ($tab_enr as $key => $value) {
				switch ($key) {
					case "titre": // Si le titre a été modifié
						$reqEnrTitre = "UPDATE histoire 
							SET titre = '{$tableauNouvellesDonnees["titre"]}'
							WHERE histoire.id = '{$tableauNouvellesDonnees["num"]}'
							";
						$resEnrTitre = mysqli_query($connexion, $reqEnrTitre) 
						or die ("\"" . $reqEnrTitre . "\"" . " n'a pas fonctionné");
						break;

						echo $resEnrTitre;

					case "options": // Si des options ont été ajoutée
						$reqEnrOptions = "UPDATE histoire 
							SET options = '{$tableauNouvellesDonnees["options"]}'
							WHERE histoire.id = '{$tableauNouvellesDonnees["num"]}'
							";
						$resEnrOptions = mysqli_query($connexion, $reqEnrOptions); 
						if (!$resEnrOptions) { echo "\"" . $reqEnrOptions . "\"" . " n'a pas fonctionné"; }
						break;

					default:
						break;
				}
			} echo "Données enregistrées avec succès. Veuillez recharger la page (F5).";
		}

	
?>
<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
	<link rel="stylesheet" href="../css/bo.css" />
	<title>P4C : Back-Office</title>
</head>
<body>

	<!-- Formulaire de recherche par ID -->
	<form method="post" action="backo.php">
		<label for="num">Numéro de page : </label>
		<input type="number" name="num" />
		<input type="submit" name="rechercher" value="Rechercher" />
	</form>

	<!-- Formulaire d'ajout de choix -->
	<form method="post" action="backo.php">
		<button name="ajouter_option">Ajouter une option</button>
	</form>

	<!-- Formulaire d'enregistrement des données -->
	<form method="post" action="backo.php">
		<button name="enregistrer">Enregistrer</button>
	</form>
	
	<!-- Page courante -->
	<div class="page">
		<div class="box"> <!-- Titre -->
			<?php 
				if (isset($page)) { echo $page[$titre]; }
			?>
		</div>
		<br />
		<div class="box"> <!-- Acte - Chapitre -->
			<?php 
				if (isset($page)) { 
					echo $page[$acte] . " - " . $page[$chapitre]; }
			?>
		</div> <!-- Image -->
		<br />
		<div class="box">
			<?php 
				if (isset($page)) { echo $page[$texte]; }
			?>
		</div>
		<div class="box">
			<?php 
				if (isset($page)) { echo $page[$options]; }

			?>
		</div>
	</div>
	<!-- / Page courante -->
	
	<script src="http://code.jquery.com/jquery-3.1.1.js"></script>
	<script>
		'use strict';
		$(document).ready(function() { // On attend la fin du chargement de la page

			// Lorsque l'on clique sur "Ajouter une option", avant le rechargement de la page, on obtient une alerte de type "prompt" dans laquelle on peut ajouter la chaîne de caractère définissant la nouvelle option.
			$('button[name=ajouter_option]').on('click', function() {
			this.value = prompt('Veuillez écrire ci-dessous le texte définissant la nouvelle option :');
			this.submit();
			});


			// Lorsque l'on clique sur "Enregistrer", avant le rechargement de la page, on obtient une alerte dans laquelle on nous demande de confirmer l'enregistrement des données.
			$('button[name=enregistrer]').on('click', function() {
			this.value = alert('Enregistrer les données ?');
			this.submit();
			});
		});
	</script>
</body>
</html>