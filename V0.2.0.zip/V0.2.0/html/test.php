<?php 
	/* Ouverture d'une session, qui permet au navigateur de sauvegarder des données dans la variable superglobale "$_SESSION" */
	session_start();

	/* Connection à la base de données "par4chemins", qui contient toutes les données du jeu. */
	include('../data/connection.php');


	// Création d'une nouvelle entrée dans la table log
	$reqNewLog = "
		INSERT INTO log ('id_utilisateur', 'id_histoire')
		VALUES ('{$_SESSION["id"]}', '1')";
	$resNewLog = mysqli_query($connexion,$reqNewLog) 
		or die ("La requête SQL \"" . $reqNewLog . "\"" . " n'a pas fonctionné");
?>