<?php 
	/* Fermeture de la session */
	session_start();

	$_SESSION = [];
	session_destroy();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="UTF-8">
	<title>Déconnection en cours...</title>
</head>
<body>
	<script>
		window.onload = function() {
			document.location.href = "index.php";
		}
	</script>
</body>
</html>