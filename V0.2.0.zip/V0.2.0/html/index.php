<?php 
	/* Ouverture d'une session, qui permet au navigateur de sauvegarder des données dans la variable superglobale "$_SESSION" */
	session_start();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <link rel="stylesheet" href="book.css" />
    <title>Par 4 Chemins : le jeu</title>
</head>
<body>

	<?php
		if (isset($_POST["login"])) {
			include('../data/connection.php');
					
			$reqConnect = "SELECT * FROM utilisateur WHERE login = '{$_POST["login"]}'";
			$resConnect = mysqli_query($connexion,$reqConnect) or die("ERREUR LOGIN");

			if (mysqli_num_rows($resConnect) == 0) {
				echo "Mauvais login ! Veuillez réessayer :";
			} else {
				$tabUser = mysqli_fetch_assoc($resConnect);
				if ($tabUser["mdp"] != md5($_POST["mdp"])) { 
					echo "Mauvais mot de passe ! Veuillez réessayer :";
				} else {
					$_SESSION["login"] = $_POST["login"];
					$_SESSION["username"] = $tabUser["username"];
				}
			}
		}
	?>
	<h3>
		Bienvenue, 
		<?php 
			$nameDisplayed = (isset($_SESSION["login"])) ? $_SESSION["username"] : "cher voyageur ou chère voyageuse";
			echo $nameDisplayed;
		?>, dans une histoire à lire et à vivre.
	</h3>

	<em>Cette aventure vous est présentée par l'agence Par 4 Chemins.</em>
	<br /><br />
	<?php
		if (isset($_SESSION["login"])) {
			echo "<a href=\"first.php\">Continuer</a><br /><br /><a href=\"userdisconnect.php\">Se déconnecter</a>";
		} else {
			include("userconnect.php");
		}
			
	?>
</body>
</html>