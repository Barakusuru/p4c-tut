<?php 
	/* NOTES DE CODAGE
		. Debug :
			- mise en place de var_dump un peu partout, c'est pour afficher le contenu d'une variable

		. Problèmes d'accents :
			- les problèmes d'accents de SQL semblent presque résolus
			- problème d'accent sur les choix
				-> solution temporaire : utf8_encode(choix)

		. F5 destructif :
			- F5 détruit le chemin d'accès pour une raison inconnue

	*/
	echo "Début du code<br />";
	echo "Encodage :" . mb_internal_encoding() . "<br /><br />";


	// [Prérequis]

	/* Ouverture d'une session, qui permet au navigateur de sauvegarder des données dans la variable superglobale "$_SESSION" */
	session_start();

	/* Connection à la base de données "par4chemins", qui contient toutes les données du jeu. */
	include('../data/connection.php');

	$chx = []; // Initialisation du tableau des choix

	// TEST : entrée manuelle d'un id de session
	$_SESSION["id"] = 1;
?>

<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="utf-8" >
	<meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <link rel="stylesheet" href="../css/gamespace.css" />
    <title>Par 4 Chemins : Le Jeu</title>
</head>

<body>
	<!-- Script jQuery -->
	<script src="http://code.jquery.com/jquery-3.1.1.js"></script>
	<script src="../js/error.js"></script>

	<!-- Script PHP -->
	<?php
		/*
		. Lorsque le joueur arrive sur la page pour la première fois :
			- s'il vient de commencer une nouvelle partie, on charge la première page ;
			- sinon, si le joueur a déjà une partie sauvegardée, on charge la dernière page visitée.

		. Ensuite, lorsque le joueur clique sur un choix, on recharge la page et on affiche la page suivante, selon la page d'avant et le choix cliqué.

		. Les choix qui lui correspondent sont recherchés puis affichés.

		. Enfin, cette nouvelle page est enregistrée en tant que dernière page visitée, pour la prochaine visite du joueur.

		LIEU D'AFFICHAGE DES RESSOURCES
			HISTOIRE : <div class="txt_">Ici !</div>
			CHOIX    : <div class="chx_">Ici !</div>
		*/

		if (!(isset($_POST["choix"]))) {
		// Première visite sur la page :

			// - Nouvelle partie ?
			if (isset($_POST["valeurEntree"])) { 
			// $_POST["valeurEntree"] est une valeur définie en cliquant sur "Commencer une nouvelle partie" de la page first.php

				// Dans le cas d'une nouvelle partie, on cherche donc la première page, c'est-à-dire celle dont l'attribut histoire.id est égal à 1
				$reqHist = "SELECT * FROM histoire WHERE histoire.id = 1";
				$resHist = mysqli_query($connexion,$reqHist) 
					or die ("La requête SQL \"" . $reqHist . "\"" . " n'a pas fonctionné");

				echo "Query Histoire :";
				var_dump($resHist);

				// De plus, on crée une nouvelle entrée dans la table log, pour sauvegarder l'histoire
				// Suppression de toutes les précédentes entrées pour le même id_utilisateur (si l'utilisateur avait déjà une partie en cours)
				$reqDelLog = "DELETE FROM log WHERE log.id_utilisateur = '{$_SESSION["id"]}'";
				$resDelLog = mysqli_query($connexion,$reqDelLog)
					or die ("La requête SQL \"" . $reqDelLog . "\"" . " n'a pas fonctionné");

				echo "Query Delete Log :";
				var_dump($resDelLog);

				// Création d'une nouvelle entrée dans la table log 
				$dateLog = date("Y-m-d H:i:s");
				$sessionID = $_SESSION["id"];

				$reqNewLog = "
					INSERT INTO log (
						id, 
						id_utilisateur, 
						id_histoire, 
						backup_histoire, 
						backup_choix, 
						datetime)
					VALUES (
						NULL, 
						'$sessionID', 
						'1', 
						'', 
						'', 
						'$dateLog')";
				$resNewLog = mysqli_query($connexion,$reqNewLog);	
			}

			// - Partie sauvegardée ?
			else {
				// On cherche à récupérer la page où le joueur s'est arrêté
				// Elle se trouve dans log.id_histoire pour chaque utilisateur

				// On cherche donc tout d'abord log.id_histoire pour l'utilisateur connecté
				$reqLogHist = "
					SELECT id_histoire 
					FROM log 
					WHERE log.id_utilisateur = '{$_SESSION["id"]}'";
				$resLogHist = mysqli_query($connexion,$reqLogHist) 
					or die ("La requête SQL \"" . $reqLogHist . "\"" . " n'a pas fonctionné");

				// Ensuite, on stocke le résultat de la requête dans une variable $tabLogHist, qui contient donc log.id_histoire lorsque log.id_utilisateur = utilisateur.id
				$tabLogHist = mysqli_fetch_assoc($resLogHist);

				// Enfin, on cherche l'histoire.id correspondante à ce log.id_histoire
				$reqHist = "
					SELECT * 
					FROM histoire 
					WHERE histoire.id = '{$tabLogHist["id_histoire"]}'";
				$resHist = mysqli_query($connexion,$reqHist) 
					or die ("La requête SQL \"" . $reqHist . "\"" . " n'a pas fonctionné");	
			}

		} else {
		// En cours de partie :

			// On cherche à récupérer la suite de l'histoire en cours
			// Elle se trouve dans rel_histoire_choix.id_suite, et dépend donc de choix.id et log.id_histoire, pour chaque utilisateur

			// On cherche donc tout d'abord le premier paramètre : choix.id
			$reqChxId = "
				SELECT id
				FROM choix
				WHERE choix.contenu = '{$_POST["choix"]}'";
			$resChxId = mysqli_query($connexion,$reqChxId) 
				or die ("La requête SQL \"" . $reqChxId . "\"" . " n'a pas fonctionné");

		echo " resChxId : ";
		var_dump($resChxId);

			// On cherche aussi le second paramètre, qui est log.id_histoire pour l'utilisateur connecté
			$reqLogHist = "
				SELECT id_histoire
				FROM log 
				WHERE log.id_utilisateur = '{$_SESSION["id"]}'";
			$resLogHist = mysqli_query($connexion,$reqLogHist) 
				or die ("La requête SQL \"" . $reqLogHist . "\"" . " n'a pas fonctionné");

			/* Ensuite, on stocke les résultats de ces deux requêtes dans les variables $tabChxId et $tabLogHist, qui contiennent donc respectivement :
				- choix.id du choix fait ;
				- log.id_histoire lorsque log.id_utilisateur = utilisateur.id.
			*/
			$tabChxId   = mysqli_fetch_assoc($resChxId);
			$tabLogHist = mysqli_fetch_assoc($resLogHist);

			// DEBUG
			var_dump($tabLogHist["id_histoire"]);
			var_dump($_POST["choix"]);
			var_dump($tabChxId["id"]);

			// On va ainsi pouvoir chercher la suite de l'histoire selon ses paramètres :
			$reqSuite = "
				SELECT id_suite
				FROM rel_histoire_choix 
				WHERE rel_histoire_choix.id_choix = '{$tabChxId["id"]}'
				AND rel_histoire_choix.id_histoire = '{$tabLogHist["id_histoire"]}'";
			$resSuite = mysqli_query($connexion,$reqSuite) 
				or die ("La requête SQL \"" . $reqSuite . "\"" . " n'a pas fonctionné");
			$tabSuite = mysqli_fetch_assoc($resSuite);

			$reqHist = "
				SELECT *
				FROM histoire
				WHERE histoire.id = '{$tabSuite["id_suite"]}'";
			$resHist = mysqli_query($connexion,$reqHist) 
				or die ("La requête SQL \"" . $reqHist . "\"" . " n'a pas fonctionné");

			var_dump($resHist);
		}

		// A ce stade, on doit vérifier si l'utilisateur a bien une partie d'histoire à afficher
		// Dans le cas contraire, on doit le rediriger vers la page de connexion : une "erreur d'histoire" est survenue.
		if (!(isset($resHist))) { 
			die (
				"ERREUR HISTOIRE
				<br />
				<button name=\"connection_error\">Se reconnecter</button>"); 
		}

		// Une fois que l'histoire est recherchée, on range ses données dans une variable nommée $tabHist :
		$tabHist = mysqli_fetch_assoc($resHist);

		// DEBUG
		var_dump($tabHist);

		// Ensuite,	on lui attribue les choix correspondants :
		// Pour cela, on fait le lien entre la table relationnelle et l'histoire :
		$reqRel = "
			SELECT id_choix
			FROM rel_histoire_choix
			WHERE rel_histoire_choix.id_histoire = '{$tabHist["id"]}'";
		$resRel = mysqli_query($connexion,$reqRel)
			or die ("La requête SQL \"" . $reqRel . "\"" . " n'a pas fonctionné");

		// Puis, entre la table relationnelle et les choix :
		$i = 0;
		while ($tabRel = mysqli_fetch_assoc($resRel)) {
			$reqChx = "
				SELECT contenu 
				FROM choix
				WHERE choix.id = '{$tabRel["id_choix"]}'";
			$resChx = mysqli_query($connexion,$reqChx)
				or die ("La requête SQL \"" . $reqChx . "\"" . " n'a pas fonctionné");

			$tabChx = mysqli_fetch_assoc($resChx);
			$chx[$i] = $tabChx["contenu"];
			$i++;
		}

		// Enfin, on enregistre l'id correspondant à l'avancement du joueur dans la table log qui lui correspond :
		// On entre donc la valeur $tabHist["id"] pour l'utilisateur connecté
		$reqSaveLog = "
			UPDATE log
			SET id_histoire = '{$tabHist["id"]}'
			WHERE log.id_utilisateur = '{$_SESSION["id"]}'";
		$resSaveLog = mysqli_query($connexion,$reqSaveLog) 
			or die ("La requête SQL \"" . $reqSaveLog . "\"" . " n'a pas fonctionné");
	?>

	<!-- Fenêtre du jeu -->
	<div class="game_">

		<!-- Cadre accueillant l'illustration du jeu qui correspond à l'avancement du joueur -->
		<img class="img_" src="../../media/starlight.png" />

		<!-- Texte de l'histoire -->
		<div class="txt_">
			<?php
				// Ici, on affiche la partie de l'histoire correspondant à l'avancement du joueur :
				echo "<h3>{$tabHist["titre"]}</h3>{$tabHist["texte"]}";

				// DEBUG
				var_dump($tabHist);
			?>
			<!-- Choix du joueur -->
			<div class="chx_">
				<form method="post" action="game.php">
					<?php
						// Ici, on affiche les choix correspondant à la partie de l'histoire chargée :
						for ($nbChx = 0; $nbChx < count($chx); $nbChx++) {
							echo "
								<input 
								type=\"submit\" 
								name=\"choix\" 
								value=\"". utf8_encode($chx[$nbChx]) . "\" />
								<br />";
						}
					?>
				</form>
			</div>
		</div>

		<!-- Elements extérieurs : ici, l'inventaire et le journal / carnet de bord -->
		<div class="ext_">
			<div class="inv_">Inventaire</div>
			<div class="cdb_">Journal</div>
			<div class="bo_"><a href="backo.php">Back-Office</a></div>
		</div>
	</div>

	<!-- Gestion du positionnement de l'image selon l'appareil et son orientation (en cours) -->
	<script src="../js/swap.js"></script>
</body>
</html>