<br />
<form method="post" action="index.php">
	<label for="login">Login : </label>
	<input type="text" name="login" />

	<label for="mdp">Mot de passe : </label>
	<input type="text" name="mdp" />

	<input type="submit" name="continuer" value="Continuer" />
</form>